using SharpVectors.Converters;
using SharpVectors.Renderers.Wpf;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace one_armed_bandit
{
    public partial class MainWindow : Window
    {
        Random random = new Random();

        // Ezt az egy értéket kell módosítani, ha teszteléskor kevesebb szimbólummal szeretnél játszani.
        // Példa: 7 = mind a 7 SVG szimbólum, 4 = csak az első 4 SVG szimbólum.
        int symbolCountOnReel = 7;

        int balance = 100;
        int spinCost = 10;

        const double symbolHeight = 58;

        List<string> allSymbols = new List<string>();
        Dictionary<string, DrawingImage> symbolImages = new Dictionary<string, DrawingImage>();

        ReelState reel1;
        ReelState reel2;
        ReelState reel3;

        string reel1FinalSymbol = "";
        string reel2FinalSymbol = "";
        string reel3FinalSymbol = "";

        public MainWindow()
        {
            InitializeComponent();

            reel1 = new ReelState(Reel1Panel);
            reel2 = new ReelState(Reel2Panel);
            reel3 = new ReelState(Reel3Panel);

            UpdateBalanceText();
            ResultText.Text = "Eredmény:";
            ResultTextResult.Text = "-";

            LoadSymbolsFromAssetsFolder();
            SetRandomStartSymbols();
        }

        private void LoadSymbolsFromAssetsFolder()
        {
            string assetsFolder = FindAssetsFolder();

            if (assetsFolder == "")
            {
                MessageBox.Show("Nem található az assets mappa. Hozz létre egy assets mappát, és tedd bele az SVG fájlokat.");
                SpinButton.IsEnabled = false;
                return;
            }

            allSymbols = Directory
                .GetFiles(assetsFolder, "slot-machine-*-symbol.svg")
                .OrderBy(filePath => filePath)
                .Take(symbolCountOnReel)
                .ToList();

            if (allSymbols.Count == 0)
            {
                MessageBox.Show("Nem található ilyen nevű SVG: slot-machine-*-symbol.svg");
                SpinButton.IsEnabled = false;
                return;
            }

            foreach (string symbolPath in allSymbols)
            {
                symbolImages[symbolPath] = LoadSvgAsDrawingImage(symbolPath);
            }
        }

        private string FindAssetsFolder()
        {
            string currentFolder = AppDomain.CurrentDomain.BaseDirectory;

            for (int i = 0; i < 6; i++)
            {
                string possibleAssetsFolder = Path.Combine(currentFolder, "assets");

                if (Directory.Exists(possibleAssetsFolder))
                {
                    return possibleAssetsFolder;
                }

                DirectoryInfo parentFolder = Directory.GetParent(currentFolder);

                if (parentFolder == null)
                {
                    break;
                }

                currentFolder = parentFolder.FullName;
            }

            return "";
        }

        private DrawingImage LoadSvgAsDrawingImage(string filePath)
        {
            WpfDrawingSettings settings = new WpfDrawingSettings();
            settings.IncludeRuntime = true;
            settings.TextAsGeometry = true;

            FileSvgReader reader = new FileSvgReader(settings);
            DrawingGroup drawing = reader.Read(filePath);

            DrawingImage image = new DrawingImage(drawing);
            image.Freeze();

            return image;
        }

        private void SetRandomStartSymbols()
        {
            SetRandomSymbolsForReel(reel1);
            SetRandomSymbolsForReel(reel2);
            SetRandomSymbolsForReel(reel3);
        }

        private void SetRandomSymbolsForReel(ReelState reel)
        {
            for (int i = 0; i < reel.Symbols.Length; i++)
            {
                reel.Symbols[i] = GetRandomSymbol();
            }

            RefreshReelView(reel);
        }

        private async void SpinButton_Click(object sender, RoutedEventArgs e)
        {
            if (balance < spinCost)
            {
                ResultText.Text = "Nincs elég kredit!";
                ResultTextResult.Text = "";
                return;
            }

            balance -= spinCost;
            UpdateBalanceText();

            ResultText.Text = "Pörgetés...";
            ResultTextResult.Text = "-";

            SpinButton.IsEnabled = false;

            Task<string> reel1Task = SpinReel(reel1, 28, 35, 160);
            Task<string> reel2Task = SpinReel(reel2, 36, 35, 185);
            Task<string> reel3Task = SpinReel(reel3, 44, 35, 220);

            reel1FinalSymbol = await reel1Task;
            reel2FinalSymbol = await reel2Task;
            reel3FinalSymbol = await reel3Task;

            CheckResult();

            SpinButton.IsEnabled = true;
        }

        private async Task<string> SpinReel(ReelState reel, int spinSteps, int fastestDuration, int slowestDuration)
        {
            for (int i = 0; i < spinSteps; i++)
            {
                double progress = (double)i / (spinSteps - 1);
                double slowedProgress = progress * progress;
                int currentDuration = fastestDuration + (int)((slowestDuration - fastestDuration) * slowedProgress);

                await AnimateOneSymbolStep(reel, currentDuration);

                // Ez a rész tartja folyamatossá az animációt:
                // ami fent bejött, az lesz a felső látható elem,
                // a korábbi felső lesz a középső,
                // a korábbi középső lesz az alsó.
                reel.Symbols[3] = reel.Symbols[2];
                reel.Symbols[2] = reel.Symbols[1];
                reel.Symbols[1] = reel.Symbols[0];
                reel.Symbols[0] = GetRandomSymbol();

                RefreshReelView(reel);
            }

            return reel.Symbols[2];
        }

        private Task AnimateOneSymbolStep(ReelState reel, int duration)
        {
            TaskCompletionSource<bool> taskCompletion = new TaskCompletionSource<bool>();

            DoubleAnimation animation = new DoubleAnimation();
            animation.From = -symbolHeight;
            animation.To = 0;
            animation.Duration = TimeSpan.FromMilliseconds(duration);
            animation.EasingFunction = new QuadraticEase
            {
                EasingMode = EasingMode.EaseInOut
            };

            animation.Completed += (sender, e) =>
            {
                taskCompletion.SetResult(true);
            };

            reel.MoveTransform.BeginAnimation(TranslateTransform.YProperty, animation);

            return taskCompletion.Task;
        }

        private void RefreshReelView(ReelState reel)
        {
            reel.MoveTransform.BeginAnimation(TranslateTransform.YProperty, null);
            reel.MoveTransform.Y = -symbolHeight;

            reel.Panel.Children.Clear();

            for (int i = 0; i < reel.Symbols.Length; i++)
            {
                reel.Panel.Children.Add(CreateSymbolImage(reel.Symbols[i]));
            }
        }

        private Image CreateSymbolImage(string symbolPath)
        {
            Image image = new Image();
            image.Source = symbolImages[symbolPath];
            image.Height = symbolHeight;
            image.Width = 110;
            image.Stretch = Stretch.Uniform;
            image.Margin = new Thickness(8, 0, 8, 0);

            return image;
        }

        private string GetRandomSymbol()
        {
            int randomIndex = random.Next(0, allSymbols.Count);
            return allSymbols[randomIndex];
        }

        private void CheckResult()
        {
            ResultText.Text = "Eredmény:";

            if (reel1FinalSymbol == reel2FinalSymbol && reel2FinalSymbol == reel3FinalSymbol)
            {
                balance += 50;
                ResultTextResult.Text = "WIN! (+50)";
            }
            else if (reel1FinalSymbol == reel2FinalSymbol ||
                     reel1FinalSymbol == reel3FinalSymbol ||
                     reel2FinalSymbol == reel3FinalSymbol)
            {
                balance += 20;
                ResultTextResult.Text = "WIN! (+20)";
            }
            else
            {
                ResultTextResult.Text = "LOSE!";
            }

            UpdateBalanceText();
        }

        private void UpdateBalanceText()
        {
            BalanceTextCredit.Text = balance + " kredit";
        }
    }

    public class ReelState
    {
        public StackPanel Panel;
        public TranslateTransform MoveTransform;
        public string[] Symbols = new string[4];

        public ReelState(StackPanel panel)
        {
            Panel = panel;
            MoveTransform = new TranslateTransform();
            Panel.RenderTransform = MoveTransform;
        }
    }
}
